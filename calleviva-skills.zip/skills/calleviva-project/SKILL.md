---
name: calleviva-project
description: Master skill for CalleViva.club, a web-based Food Truck tycoon game. Use when working on any CalleViva task including setup, architecture decisions, deployment, or general project questions. Provides project structure, conventions, environment setup, and cross-cutting concerns.
---

# CalleViva Project Skill

CalleViva.club is a web tycoon game where players manage Food Trucks in an AI-driven city.

## Project Identity

- **Name:** CalleViva.club
- **Slogan:** ¡La calle está viva!
- **Genre:** Tycoon / Economic Simulation
- **Audience:** 11+ years (family-friendly)
- **Platform:** Web (desktop + mobile responsive)

## Tech Stack

| Layer | Technology |
|-------|------------|
| Frontend | React 18 + TypeScript + PixiJS + Vite + Tailwind |
| Backend | Go 1.22 + Chi router |
| Database | PostgreSQL 16 |
| Cache | Redis 7 |
| AI | Claude API (Anthropic) |
| Deploy | Ubuntu 24.04 + nginx + systemd |

## Server Paths

```
/opt/CalleViva/           # Project root
├── backend/              # Go API (port 8082)
├── frontend/             # React source
├── database/migrations/  # SQL files
├── scripts/              # Utility scripts
└── docs/                 # GDD, API docs

/var/www/calleviva/       # Compiled frontend (nginx serves this)
/opt/.claude/skills/      # AI agent skills
```

## Key Commands

```bash
make setup        # Install all dependencies
make setup-db     # Create DB + run migrations
make dev          # Run backend + frontend
make build        # Compile for production
make deploy       # Full deploy cycle
make logs         # View service logs
```

## Environment Variables

Required in `/opt/CalleViva/.env`:

```
PORT=8082
DB_HOST=localhost
DB_NAME=calleviva
DB_USER=calleviva
DB_PASSWORD=<secret>
REDIS_HOST=localhost
CLAUDE_API_KEY=sk-ant-...
JWT_SECRET=<secret>
FRONTEND_URL=https://calleviva.club
```

## Code Conventions

### Naming
- Go packages: lowercase, single word (`game`, `storage`)
- Go files: snake_case (`game_session.go`)
- React components: PascalCase (`GameHeader.tsx`)
- CSS classes: kebab-case or Tailwind utilities

### Git
- Branches: `main`, `develop`, `feature/*`, `fix/*`
- Commits: conventional commits (`feat:`, `fix:`, `docs:`)

## Color Palette

```
Primary:   #FF6B6B (coral), #FFE66D (mango), #2EC4B6 (agua)
Secondary: #FF9F43 (papaya), #5C8A4D (hoja), #E17055 (terracota)
Neutral:   #2D3436 (carbon), #F5F0E6 (crema), #DFE6E9 (gris)
```

**Rule:** Never use purples/lavenders (avoid "AI aesthetic").

## Related Skills

- `calleviva-backend` — Go API patterns and handlers
- `calleviva-frontend` — React + PixiJS components
- `calleviva-game-logic` — Game systems and formulas
- `calleviva-ai` — Claude API integration

## Key Files

- `/opt/CalleViva/CLAUDE.md` — Complete project documentation
- `/opt/CalleViva/docs/GDD.md` — Game Design Document
- `/opt/CalleViva/docs/API.md` — API endpoint reference
