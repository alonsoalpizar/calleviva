---
name: calleviva-backend
description: Backend development skill for CalleViva Go API. Use when creating endpoints, handlers, services, database queries, or any backend Go code. Provides patterns for Chi router, PostgreSQL with pgx, Redis caching, JWT auth, and project-specific conventions.
---

# CalleViva Backend Skill

Go API server using Chi router, PostgreSQL (pgx), and Redis.

## Project Structure

```
backend/
├── cmd/server/main.go       # Entry point
└── internal/
    ├── api/
    │   ├── routes.go        # Route definitions
    │   ├── middleware/      # Auth, logging, CORS
    │   └── handlers/        # HTTP handlers
    ├── game/                # Game logic
    │   ├── simulation/      # Day simulation engine
    │   ├── economy/         # Money, prices, costs
    │   ├── customers/       # Customer generation
    │   ├── locations/       # Location system
    │   └── events/          # Event system
    ├── ai/                  # Claude integration
    ├── storage/
    │   ├── postgres/        # DB queries
    │   └── redis/           # Cache operations
    └── models/              # Data structures
```

## Handler Pattern

```go
func (h *GameHandler) GetGameState(w http.ResponseWriter, r *http.Request) {
    // 1. Extract params
    gameID := chi.URLParam(r, "id")
    userID := r.Context().Value("user_id").(string)
    
    // 2. Validate
    if gameID == "" {
        respondError(w, http.StatusBadRequest, "game_id required")
        return
    }
    
    // 3. Execute business logic
    state, err := h.gameService.GetState(r.Context(), gameID, userID)
    if err != nil {
        if errors.Is(err, ErrNotFound) {
            respondError(w, http.StatusNotFound, "game not found")
            return
        }
        respondError(w, http.StatusInternalServerError, "internal error")
        return
    }
    
    // 4. Respond
    respondJSON(w, http.StatusOK, state)
}
```

## Response Helpers

```go
func respondJSON(w http.ResponseWriter, status int, data interface{}) {
    w.Header().Set("Content-Type", "application/json")
    w.WriteHeader(status)
    json.NewEncoder(w).Encode(data)
}

func respondError(w http.ResponseWriter, status int, message string) {
    respondJSON(w, status, map[string]string{"error": message})
}
```

## Service Pattern

```go
type GameService struct {
    db    *postgres.DB
    cache *redis.Client
}

func (s *GameService) GetState(ctx context.Context, gameID, userID string) (*GameState, error) {
    // Check ownership
    game, err := s.db.GetGame(ctx, gameID)
    if err != nil {
        return nil, fmt.Errorf("get game: %w", err)
    }
    if game.PlayerID != userID {
        return nil, ErrForbidden
    }
    
    // Business logic here
    return &GameState{...}, nil
}
```

## Database Queries (pgx)

```go
func (db *DB) GetGame(ctx context.Context, id string) (*models.Game, error) {
    var g models.Game
    err := db.pool.QueryRow(ctx, `
        SELECT id, player_id, world_type, game_day, money, reputation, status
        FROM game_sessions
        WHERE id = $1 AND deleted_at IS NULL
    `, id).Scan(&g.ID, &g.PlayerID, &g.WorldType, &g.GameDay, &g.Money, &g.Reputation, &g.Status)
    
    if err == pgx.ErrNoRows {
        return nil, ErrNotFound
    }
    return &g, err
}
```

## Redis Cache Pattern

```go
func (c *Cache) GetOrSet(ctx context.Context, key string, ttl time.Duration, fn func() (interface{}, error)) (interface{}, error) {
    // Try cache first
    val, err := c.client.Get(ctx, key).Result()
    if err == nil {
        return val, nil
    }
    
    // Generate value
    result, err := fn()
    if err != nil {
        return nil, err
    }
    
    // Store in cache
    c.client.Set(ctx, key, result, ttl)
    return result, nil
}
```

## JWT Auth Middleware

```go
func (m *AuthMiddleware) Handler(next http.Handler) http.Handler {
    return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
        token := extractToken(r)
        if token == "" {
            respondError(w, http.StatusUnauthorized, "missing token")
            return
        }
        
        claims, err := m.validateToken(token)
        if err != nil {
            respondError(w, http.StatusUnauthorized, "invalid token")
            return
        }
        
        ctx := context.WithValue(r.Context(), "user_id", claims.UserID)
        next.ServeHTTP(w, r.WithContext(ctx))
    })
}
```

## Adding a New Endpoint

1. Define handler in `internal/api/handlers/`
2. Add route in `internal/api/routes.go`
3. Create/update service in appropriate `internal/` package
4. Add DB queries if needed in `internal/storage/postgres/`
5. Update models in `internal/models/`
6. Document in `/opt/CalleViva/docs/API.md`

## Error Handling

```go
var (
    ErrNotFound   = errors.New("not found")
    ErrForbidden  = errors.New("forbidden")
    ErrBadRequest = errors.New("bad request")
)

// Wrap errors with context
return fmt.Errorf("game service: get state: %w", err)
```

## Testing

```go
func TestGetGame(t *testing.T) {
    // Setup
    db := setupTestDB(t)
    handler := NewGameHandler(db)
    
    // Create test request
    req := httptest.NewRequest("GET", "/api/v1/games/123", nil)
    rec := httptest.NewRecorder()
    
    // Execute
    handler.GetGameState(rec, req)
    
    // Assert
    assert.Equal(t, http.StatusOK, rec.Code)
}
```
