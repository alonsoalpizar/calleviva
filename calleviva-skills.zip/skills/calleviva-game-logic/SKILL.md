---
name: calleviva-game-logic
description: Game systems and balancing skill for CalleViva. Use when implementing or modifying game mechanics including economy, customer behavior, locations, events, weather, reputation, or progression. Provides formulas, balancing guidelines, and world data structures.
---

# CalleViva Game Logic Skill

Core game systems, formulas, and balancing for the Food Truck tycoon.

## Game Loop

```
┌─────────────────────────────────────────────────────────┐
│  DAILY LOOP                                             │
├─────────────────────────────────────────────────────────┤
│  1. Morning: Check weather, events, news               │
│  2. Planning: Buy ingredients, choose location, prices │
│  3. Simulation: Run day (customers come/go, sales)     │
│  4. Results: Summary, profit, reputation change        │
│  5. Upgrade: Optional improvements                     │
│  6. Repeat                                             │
└─────────────────────────────────────────────────────────┘
```

## Economy System

### Profit Formula

```
DAILY_PROFIT = TOTAL_SALES - INGREDIENT_COSTS - LOCATION_COST
```

### Price Elasticity

```go
func CalculateDemandFactor(actualPrice, expectedPrice int) float64 {
    ratio := float64(actualPrice) / float64(expectedPrice)
    
    if ratio > 1.3 {
        return 0.3  // Too expensive, most leave
    } else if ratio > 1.1 {
        return 0.7  // Slightly expensive
    } else if ratio < 0.8 {
        return 0.9  // Suspiciously cheap
    }
    return 1.0  // Fair price
}
```

### Suggested Margins

| Product Type | Target Margin |
|--------------|---------------|
| Basic | 50-60% |
| Premium | 55-65% |
| Advanced | 60-70% |

### Progression Curve

| Day Range | Expected Money | Reputation | Unlocks |
|-----------|----------------|------------|---------|
| 1-7 | ₡10k-25k | 0-30 | Tutorial |
| 8-30 | ₡25k-80k | 30-60 | New locations |
| 31-90 | ₡80k-250k | 60-85 | Second truck |
| 90+ | ₡250k+ | 85+ | Franchise |

## Customer System

### Customer Attributes

```go
type Customer struct {
    Budget      BudgetLevel  // Low, Medium, High
    Patience    int          // 1-10 (queue tolerance)
    Preference  FoodType     // Sweet, Salty, Fresh
    Loyalty     int          // 0-100 (return probability)
    Mood        int          // 1-10 (affected by weather, wait)
}
```

### Customer Decision Flow

```go
func (c *Customer) WillBuy(menu []Product, queueLength int) (bool, string) {
    // 1. Check if desired product exists
    product := c.findPreferredProduct(menu)
    if product == nil {
        return false, "no_product"
    }
    
    // 2. Check price tolerance
    if product.Price > c.maxPrice() {
        return false, "too_expensive"
    }
    
    // 3. Check queue tolerance
    if queueLength > c.Patience {
        return false, "queue_long"
    }
    
    return true, "purchase"
}
```

### Customer Generation

```go
func GenerateCustomersPerHour(location Location, hour int, weather Weather, reputation int) int {
    base := location.BaseTraffic
    hourMod := location.HourModifier(hour)
    weatherMod := weather.TrafficModifier()
    repMod := 1.0 + (float64(reputation) / 200.0)  // Max +50% at rep 100
    
    return int(float64(base) * hourMod * weatherMod * repMod)
}
```

## Location System

### Location Properties

```go
type Location struct {
    ID           string
    Name         string
    BaseTraffic  int
    CostPerDay   int
    ClientType   string    // families, workers, students, tourists
    PeakHours    []int
    UnlockRep    int
}
```

### Traffic by Hour (Example: Industrial Zone)

```
Hour  | Modifier
------|----------
06-08 | 0.4
09-10 | 0.3
11-13 | 1.0 (PEAK)
14-15 | 0.5
16-17 | 0.6
18    | 0.4
```

## Weather System

### Weather Effects

```go
var WeatherEffects = map[Weather]struct {
    TrafficMod  float64
    ProductMods map[string]float64
}{
    Sunny:  {1.2, map[string]float64{"cold": 1.3, "hot": 0.8}},
    Cloudy: {1.0, map[string]float64{}},
    Rainy:  {0.75, map[string]float64{"cold": 0.7, "hot": 1.3}},
    Storm:  {0.5, map[string]float64{"cold": 0.5, "hot": 1.5}},
}
```

### Weather Probability

```go
func GenerateWeather() Weather {
    r := rand.Float64()
    switch {
    case r < 0.50: return Sunny
    case r < 0.75: return Cloudy
    case r < 0.95: return Rainy
    default: return Storm
    }
}
```

## Reputation System

### Daily Reputation Change

```go
func CalculateReputationChange(served, lost int, avgSatisfaction float64) int {
    change := 0
    
    // Positive: satisfied customers
    change += int(float64(served) * avgSatisfaction * 0.1)
    
    // Negative: lost customers
    change -= lost * 0.3
    
    // Bonus: streak (5+ positive days)
    if onStreak {
        change += 2
    }
    
    return clamp(change, -10, 10)
}
```

### Reputation Effects

| Level | Range | Traffic Bonus | Unlocks |
|-------|-------|---------------|---------|
| Unknown | 0-20 | +0% | - |
| Known | 21-40 | +10% | - |
| Popular | 41-60 | +20% | Beach, upgrades |
| Famous | 61-80 | +30% | Stadium |
| Legend | 81-100 | +50% | Special events |

## World Data Structure

### Product Definition

```json
{
  "id": "churchill",
  "name": "Churchill",
  "icon": "🍨",
  "baseCost": 400,
  "suggestedPrice": 900,
  "difficulty": 2,
  "unlockReputation": 20,
  "ingredients": ["ice", "syrup_premium", "condensed_milk", "fruit"],
  "category": "cold"
}
```

### Location Definition

```json
{
  "id": "zona_industrial",
  "name": "Zona Industrial",
  "icon": "🏭",
  "costPerDay": 600,
  "baseTraffic": 10,
  "clientType": "workers",
  "peakHours": [11, 12, 13],
  "unlockReputation": 0
}
```

### Event Definition

```json
{
  "id": "feria_palmares",
  "name": "Fiestas de Palmares",
  "type": "annual",
  "duration": 14,
  "effects": {
    "trafficModifier": 2.0,
    "specialLocation": "feria_grounds"
  }
}
```

## Balancing Guidelines

1. **First-time user experience:** Day 1 should guarantee profit if player follows tutorial
2. **Challenge curve:** Difficulty increases gradually, never sudden spikes
3. **Recovery:** Bankruptcy should be avoidable with 2-3 days warning
4. **Meaningful choices:** Each decision should have visible consequences
5. **Reward experimentation:** Trying new locations/products should sometimes pay off
6. **AI unpredictability:** Events and competitors should surprise occasionally

## Bankruptcy Rules

```go
func CheckBankruptcy(game *GameSession) BankruptcyStatus {
    if game.Money >= 0 {
        game.NegativeDays = 0
        return OK
    }
    
    game.NegativeDays++
    
    if game.NegativeDays >= 3 {
        return Bankrupt
    }
    
    return Warning  // Show "tough times" message
}
```

## Adding New Content

### New Product
1. Add to `worlds/costa_rica/products.json`
2. Add ingredient requirements
3. Set unlock requirements
4. Balance price/cost ratio
5. Add icon/sprite asset

### New Location
1. Add to `worlds/costa_rica/locations.json`
2. Define traffic curve by hour
3. Set unlock requirements
4. Balance cost vs traffic

### New Event
1. Add to `worlds/costa_rica/events.json`
2. Define trigger conditions
3. Set effects (traffic, prices, special locations)
4. Create narrative text for AI to generate
