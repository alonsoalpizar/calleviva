---
name: calleviva-frontend
description: Frontend development skill for CalleViva React application. Use when creating UI components, game screens, PixiJS scenes, state management, or styling. Provides patterns for React 18, TypeScript, PixiJS integration, Zustand stores, Tailwind CSS, and the CalleViva design system.
---

# CalleViva Frontend Skill

React 18 + TypeScript + PixiJS + Vite + Tailwind CSS.

## Project Structure

```
frontend/src/
├── main.tsx              # Entry point
├── App.tsx               # Router setup
├── index.css             # Global styles + Tailwind
├── components/
│   ├── ui/               # Reusable UI (Button, Panel, Modal)
│   └── game/             # Game-specific (GameHeader, SalesLog)
├── game/                 # PixiJS rendering
│   ├── scenes/           # Game scenes
│   └── sprites/          # Sprite classes
├── services/             # API clients
├── stores/               # Zustand state
└── types/                # TypeScript definitions
```

## Component Pattern

```tsx
interface GameHeaderProps {
  money: number;
  reputation: number;
  day: number;
  onBack?: () => void;
}

export const GameHeader: React.FC<GameHeaderProps> = ({ 
  money, 
  reputation, 
  day,
  onBack 
}) => {
  return (
    <header className="game-header">
      {onBack && (
        <button onClick={onBack} className="btn-secondary">
          ← Volver
        </button>
      )}
      <div className="flex gap-4">
        <Stat label="Día" value={day} />
        <Stat label="Dinero" value={`₡${money.toLocaleString()}`} color="hoja" />
        <Stat label="Reputación" value={reputation} icon="⭐" color="papaya" />
      </div>
    </header>
  );
};
```

## Zustand Store Pattern

```tsx
// stores/gameStore.ts
import { create } from 'zustand';

interface GameState {
  gameId: string | null;
  day: number;
  money: number;
  reputation: number;
  isLoading: boolean;
  
  // Actions
  setGame: (game: Partial<GameState>) => void;
  loadGame: (id: string) => Promise<void>;
  updateMoney: (delta: number) => void;
}

export const useGameStore = create<GameState>((set, get) => ({
  gameId: null,
  day: 1,
  money: 15000,
  reputation: 0,
  isLoading: false,
  
  setGame: (game) => set((state) => ({ ...state, ...game })),
  
  loadGame: async (id) => {
    set({ isLoading: true });
    try {
      const game = await gameService.getGame(id);
      set({ ...game, isLoading: false });
    } catch (error) {
      set({ isLoading: false });
      throw error;
    }
  },
  
  updateMoney: (delta) => set((state) => ({ 
    money: state.money + delta 
  })),
}));
```

## API Service Pattern

```tsx
// services/gameService.ts
import axios from 'axios';

const api = axios.create({
  baseURL: '/api/v1',
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const gameService = {
  async getGame(id: string) {
    const { data } = await api.get(`/games/${id}`);
    return data;
  },
  
  async startDay(gameId: string) {
    const { data } = await api.post(`/games/${gameId}/day/start`);
    return data;
  },
  
  async buyItems(gameId: string, items: BuyItem[]) {
    const { data } = await api.post(`/games/${gameId}/market/buy`, { items });
    return data;
  },
};
```

## Design System

### Colors (CSS Variables)

```css
:root {
  --coral: #FF6B6B;
  --mango: #FFE66D;
  --agua: #2EC4B6;
  --papaya: #FF9F43;
  --hoja: #5C8A4D;
  --terracota: #E17055;
  --carbon: #2D3436;
  --crema: #F5F0E6;
  --gris-claro: #DFE6E9;
}
```

### Button Classes

```tsx
<button className="btn-primary">Acción Principal</button>
<button className="btn-secondary">Secundario</button>
<button className="btn-warning">Advertencia</button>
<button className="btn-success">Éxito</button>
```

### Panel Component

```tsx
<div className="panel">
  <h2>Título del Panel</h2>
  <p>Contenido...</p>
</div>
```

## PixiJS Integration

```tsx
// game/scenes/SimulationScene.tsx
import { Stage, Container, Sprite, Text } from '@pixi/react';

export const SimulationScene: React.FC<{ width: number; height: number }> = ({ 
  width, 
  height 
}) => {
  return (
    <Stage width={width} height={height} options={{ backgroundColor: 0xF5F0E6 }}>
      <Container x={width / 2} y={height / 2}>
        <FoodTruckSprite />
        <CustomerSprites />
      </Container>
    </Stage>
  );
};
```

## WebSocket for Simulation

```tsx
// hooks/useSimulation.ts
export function useSimulation(gameId: string) {
  const [events, setEvents] = useState<SimEvent[]>([]);
  
  useEffect(() => {
    const ws = new WebSocket(`wss://calleviva.club/ws?game=${gameId}`);
    
    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      
      switch (data.type) {
        case 'sale':
          setEvents((prev) => [...prev, data]);
          break;
        case 'day_complete':
          // Handle day end
          break;
      }
    };
    
    return () => ws.close();
  }, [gameId]);
  
  return { events };
}
```

## Adding a New Screen

1. Create component in `src/components/game/`
2. Add route in `App.tsx`
3. Connect to Zustand store if needed
4. Add API calls via services
5. Style with Tailwind + design system classes

## TypeScript Types

```tsx
// types/game.ts
export interface GameSession {
  id: string;
  worldType: string;
  gameDay: number;
  money: number;
  reputation: number;
  status: 'active' | 'paused' | 'finished';
}

export interface Product {
  id: string;
  name: string;
  icon: string;
  baseCost: number;
  suggestedPrice: number;
}

export interface SimEvent {
  type: 'sale' | 'customer_left' | 'hour_complete' | 'day_complete';
  data: Record<string, unknown>;
  timestamp: string;
}
```

## Responsive Design

```tsx
// Mobile-first approach
<div className="
  p-4 
  md:p-6 
  lg:p-8
  grid 
  grid-cols-1 
  md:grid-cols-2 
  lg:grid-cols-3 
  gap-4
">
```

## Testing

```tsx
import { render, screen } from '@testing-library/react';
import { GameHeader } from './GameHeader';

test('displays money correctly', () => {
  render(<GameHeader money={15000} reputation={50} day={5} />);
  expect(screen.getByText('₡15,000')).toBeInTheDocument();
});
```
