---
name: calleviva-ai
description: Claude API integration skill for CalleViva. Use when implementing AI-generated content including customer dialogues, news articles, competitor decisions, tips, or any dynamic text generation. Provides prompt templates, caching strategies, fallback systems, and cost optimization patterns.
---

# CalleViva AI Skill

Claude API integration for dynamic game content generation.

## Core Principle

```
┌─────────────────────────────────────────────────────────┐
│  THE AI IS INVISIBLE TO THE PLAYER                      │
├─────────────────────────────────────────────────────────┤
│  Player should feel: "This world feels alive"           │
│  NOT: "An AI generated this"                            │
│                                                         │
│  ❌ "AI creates unique dialogues"                       │
│  ✅ "Customers say different things each time"          │
└─────────────────────────────────────────────────────────┘
```

## When to Call Claude

| Trigger | Content | Latency | Cacheable |
|---------|---------|---------|-----------|
| Sale completed | Customer dialogue | Async | Yes |
| End of day | Tip of the day | 2-3s | No |
| End of week | News article | Batch | No |
| Competitor turn | Strategy decision | Batch | No |
| Special event | Narrative text | Pre-gen | No |

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│                  AI ORCHESTRATOR                        │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  Request → Cache Check → [Hit? Return] → Claude API    │
│                              ↓                          │
│                         [Miss? Generate]                │
│                              ↓                          │
│                         Store in Cache                  │
│                              ↓                          │
│                         Return Result                   │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

## Prompt Templates

### Customer Dialogue

```go
const CustomerDialoguePrompt = `Sos un cliente costarricense comprando en un Food Truck.
Respondé con UNA frase corta (máximo 10 palabras).
Usá jerga tica natural (mae, diay, tuanis, pura vida).
No uses hashtags, emojis, ni comillas.

Contexto:
- Producto comprado: {{.Product}}
- Precio pagado: ₡{{.Price}}
- Tu satisfacción: {{.Satisfaction}}/10
- Clima actual: {{.Weather}}
- Hora del día: {{.Hour}}:00

Generá solo la frase del cliente, nada más.`
```

**Example outputs:**
- Happy: "¡Pura vida, mae!", "¡Tuanis!", "¡Qué rico está esto!"
- Neutral: "Está bien", "Gracias mae", "Ok"
- Unhappy: "Un poco caro", "Mucha espera"

### Daily Tip

```go
const DailyTipPrompt = `Sos un asesor de negocios dando un consejo corto a un vendedor de Food Truck.
El consejo debe ser específico basado en los datos del día.
Máximo 2 oraciones. Tono amigable y motivador.

Datos del día:
- Ventas totales: ₡{{.TotalSales}}
- Producto más vendido: {{.TopProduct}} ({{.TopProductQty}} unidades)
- Clientes atendidos: {{.CustomersServed}}
- Clientes perdidos: {{.CustomersLost}}
- Ubicación: {{.Location}}
- Clima: {{.Weather}}

Da un consejo práctico y específico.`
```

### Weekly News Article

```go
const WeeklyNewsPrompt = `Sos un periodista local escribiendo una nota breve sobre un negocio de comida.
Tono: Amigable, local, ligeramente humorístico.
Largo: 3-4 oraciones máximo.
Incluí el nombre del negocio.

Datos de la semana:
- Nombre del negocio: {{.BusinessName}}
- Ventas totales: ₡{{.WeeklySales}}
- Clientes totales: {{.WeeklyCustomers}}
- Reputación actual: {{.Reputation}}/100
- Producto estrella: {{.StarProduct}}
- Evento destacado: {{.HighlightEvent}}

Escribí la nota como para el periódico del pueblo.`
```

## Caching Strategy

### Context Hash

```go
func GenerateContextHash(product, satisfaction, weather, timeOfDay string) string {
    // Normalize to cacheable buckets
    satBucket := "happy"
    if satisfaction < 5 {
        satBucket = "unhappy"
    } else if satisfaction < 7 {
        satBucket = "neutral"
    }
    
    timeBucket := "morning"
    if hour >= 12 && hour < 17 {
        timeBucket = "afternoon"
    } else if hour >= 17 {
        timeBucket = "evening"
    }
    
    key := fmt.Sprintf("%s_%s_%s_%s", product, satBucket, weather, timeBucket)
    return hash(key)
}
```

### Cache Structure

```sql
-- ai_cache table
context_hash  | prompt_type     | response            | hits | expires_at
--------------+-----------------+---------------------+------+------------
abc123        | dialogue        | "¡Pura vida, mae!"  | 47   | 2024-01-15
abc123        | dialogue        | "¡Tuanis!"          | 23   | 2024-01-15
def456        | dialogue        | "Está bien"         | 12   | 2024-01-15
```

### Cache Logic

```go
func (o *Orchestrator) GetDialogue(ctx context.Context, input DialogueInput) (string, error) {
    hash := GenerateContextHash(input)
    
    // 1. Try cache
    responses, err := o.cache.GetResponses(ctx, hash, "dialogue")
    if err == nil && len(responses) >= 3 {
        // Return random from pool
        return responses[rand.Intn(len(responses))], nil
    }
    
    // 2. Generate new
    response, err := o.claude.Generate(ctx, CustomerDialoguePrompt, input)
    if err != nil {
        // 3. Fallback to predefined
        return o.getFallback(input.Satisfaction), nil
    }
    
    // 4. Store in cache (async)
    go o.cache.Store(ctx, hash, "dialogue", response)
    
    return response, nil
}
```

## Fallback System

**Always have fallbacks.** The game must work without Claude.

```go
var FallbackDialogues = map[string][]string{
    "happy": {
        "¡Pura vida!",
        "¡Tuanis!",
        "¡Qué rico!",
        "¡Muy bueno!",
        "¡Me encanta!",
    },
    "neutral": {
        "Está bien",
        "Ok, gracias",
        "Bien",
        "Gracias",
    },
    "unhappy": {
        "Muy caro",
        "Mucha fila",
        "No sé...",
        "Hmm",
    },
}

func (o *Orchestrator) getFallback(satisfaction int) string {
    var pool []string
    switch {
    case satisfaction >= 7:
        pool = FallbackDialogues["happy"]
    case satisfaction >= 4:
        pool = FallbackDialogues["neutral"]
    default:
        pool = FallbackDialogues["unhappy"]
    }
    return pool[rand.Intn(len(pool))]
}
```

## Cost Optimization

### Token Limits

```go
const (
    MaxDialogueTokens = 50
    MaxTipTokens      = 100
    MaxNewsTokens     = 200
)
```

### Rate Limiting

```go
type RateLimiter struct {
    requestsPerMinute int
    tokensPerDay      int
}

func (r *RateLimiter) CanRequest() bool {
    // Check both limits
    return r.currentRPM < r.requestsPerMinute && 
           r.currentTokens < r.tokensPerDay
}
```

### Batch Processing

```go
// For end-of-day content, batch multiple requests
func (o *Orchestrator) GenerateDayEndContent(ctx context.Context, game *Game) (*DayEndContent, error) {
    // Single request with multiple outputs
    prompt := fmt.Sprintf(`Generate the following for a Food Truck game:
1. A short tip (max 20 words)
2. A customer review (max 15 words)

Game data: %+v

Respond in JSON format:
{"tip": "...", "review": "..."}`, game)
    
    return o.claude.GenerateJSON(ctx, prompt)
}
```

## Claude API Integration

```go
type ClaudeClient struct {
    apiKey  string
    model   string
    timeout time.Duration
}

func (c *ClaudeClient) Generate(ctx context.Context, prompt string, data interface{}) (string, error) {
    // Build request
    body := map[string]interface{}{
        "model":      c.model,
        "max_tokens": 100,
        "messages": []map[string]string{
            {"role": "user", "content": renderPrompt(prompt, data)},
        },
    }
    
    req, _ := http.NewRequestWithContext(ctx, "POST", 
        "https://api.anthropic.com/v1/messages", 
        toJSON(body))
    
    req.Header.Set("x-api-key", c.apiKey)
    req.Header.Set("anthropic-version", "2023-06-01")
    req.Header.Set("content-type", "application/json")
    
    resp, err := http.DefaultClient.Do(req)
    if err != nil {
        return "", fmt.Errorf("claude request: %w", err)
    }
    defer resp.Body.Close()
    
    var result struct {
        Content []struct {
            Text string `json:"text"`
        } `json:"content"`
    }
    json.NewDecoder(resp.Body).Decode(&result)
    
    if len(result.Content) == 0 {
        return "", errors.New("empty response")
    }
    
    return result.Content[0].Text, nil
}
```

## Error Handling

```go
func (o *Orchestrator) safeGenerate(ctx context.Context, promptType string, input interface{}) string {
    // Always return something, never error to caller
    
    ctx, cancel := context.WithTimeout(ctx, 5*time.Second)
    defer cancel()
    
    result, err := o.generate(ctx, promptType, input)
    if err != nil {
        log.Printf("AI generation failed: %v, using fallback", err)
        return o.getFallback(promptType, input)
    }
    
    // Validate response
    if len(result) > 100 || containsBadContent(result) {
        log.Printf("AI response invalid, using fallback")
        return o.getFallback(promptType, input)
    }
    
    return result
}
```

## Testing

```go
func TestDialogueGeneration(t *testing.T) {
    // Test with mocked Claude
    mock := &MockClaudeClient{
        Response: "¡Pura vida!",
    }
    
    orch := NewOrchestrator(mock, cache)
    
    result, err := orch.GetDialogue(context.Background(), DialogueInput{
        Product:      "churchill",
        Satisfaction: 9,
        Weather:      "sunny",
    })
    
    assert.NoError(t, err)
    assert.NotEmpty(t, result)
    assert.LessOrEqual(t, len(result), 50)
}
```
